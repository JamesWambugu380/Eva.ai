import React from 'react';

function App() {
  return <div>Hello from Eva.ai - Your AI Friend!</div>;
}

export default App;
