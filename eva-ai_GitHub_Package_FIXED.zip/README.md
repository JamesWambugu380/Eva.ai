# Eva.ai – AI Friend App

Eva.ai is a personal AI companion that listens, speaks with a natural female voice, understands your mood, and remembers past interactions.

## Features
- Voice output (female)
- Voice input (speech-to-text)
- Mood detection and response
- Memory of conversations
- Google user login
- Clean UI with mobile support

## Author
James Wambugu  
Email: hello@eva.ai (or your Gmail for now)

## License
This project is proprietary. See LICENSE file.

## To Run the App Locally:
1. Install Node.js from https://nodejs.org
2. Open the folder in terminal and run:
   ```bash
   npm install
   npm run dev
   ```
3. Visit http://localhost:3000 in your browser.
